package iot.unipi.it.JSON;

/**
 * This indicates the type of the value of a single measure.
 * 
 * @autor d.vigna
 */
public enum SenmlValueType {
	SENML_TYPE_V, SENML_TYPE_BV, SENML_TYPE_SV
}

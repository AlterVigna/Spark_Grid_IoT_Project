#define COAP_RESPONSE_CODE_CREATED 65  // 2.01 Created

// Server IP and resource path
#define SERVER_REG_EP "coap://[fd00::1]:5683"
#define SERVICE_REG_URL "/device_registration"

#define LOG_MODULE "App"
#define LOG_LEVEL LOG_LEVEL_APP


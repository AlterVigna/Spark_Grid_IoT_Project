float random_value_generation(float min, float max);
float random_value_generation_gradual_variation(float min, float max,float max_var,float old_value);
int find_max_index(float *arr, int n);



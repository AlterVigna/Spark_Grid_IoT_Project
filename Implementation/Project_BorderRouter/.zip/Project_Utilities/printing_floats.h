void floatToString(float number, char *str, int precision);
void print_probabilities(float *outputs, int predicted_class);
void print_smart_power_meter_sensing_measurement(float voltage, float current_consumed, float current_produced, float power_factor,float instant_power,int loads_attacched);
void print_smart_transformer_sensing_measurement(float Ia,float Ib,float Ic,float Va,float Vb,float Vc);
